#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <process.h>
#include <time.h>

#include "TextLogDll_c.h"

//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------
void Screen_Nav_Info( int no ) {

}

//---------------------------------------------------------------------------------------
void Event_Message_Received() {
}
//---------------------------------------------------------------------------------------
BOOL Program_Init_Code() {
	_gInitLogDll_c();
	return TRUE;
}